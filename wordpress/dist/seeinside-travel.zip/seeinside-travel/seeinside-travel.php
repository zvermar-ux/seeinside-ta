<?php
/**
 * Plugin Name:       SeeInside Travel – Sync
 * Plugin URI:        https://ta.seeinsidesolution.com
 * Description:       Real-time sync of tours, events, hotels/apartments and visas from the SeeInside Travel system (ta.seeinsidesolution.com) into custom post types with ACF fields, plus booking & visa forms, listings, slider and page-builder templates (Elementor / Gutenberg / any theme).
 * Version:           2.11.1
 * Requires at least: 6.2
 * Requires PHP:      8.0
 * Author:            SeeInside Solution
 * Text Domain:       seeinside-travel
 * Domain Path:       /languages
 * License:           GPL-2.0-or-later
 */

defined('ABSPATH') || exit;

define('STA_VERSION', '2.11.1');
define('STA_FILE', __FILE__);
define('STA_DIR', plugin_dir_path(__FILE__));
define('STA_URL', plugin_dir_url(__FILE__));

require_once STA_DIR.'includes/helpers.php';
require_once STA_DIR.'includes/class-schema.php';
require_once STA_DIR.'includes/class-api.php';
require_once STA_DIR.'includes/class-post-types.php';
require_once STA_DIR.'includes/class-fields.php';
require_once STA_DIR.'includes/class-sync.php';
require_once STA_DIR.'includes/class-webhook.php';
require_once STA_DIR.'includes/class-render.php';
require_once STA_DIR.'includes/class-frontend.php';
require_once STA_DIR.'includes/class-slider.php';
require_once STA_DIR.'includes/class-reviews.php';
require_once STA_DIR.'includes/class-chat.php';
require_once STA_DIR.'includes/class-items.php';
require_once STA_DIR.'includes/class-cards.php';
require_once STA_DIR.'includes/class-listings.php';
require_once STA_DIR.'includes/class-finder.php';
require_once STA_DIR.'includes/class-offer-finder.php';
require_once STA_DIR.'includes/class-site.php';
require_once STA_DIR.'includes/class-searchbox.php';
require_once STA_DIR.'includes/class-quicksearch.php';
require_once STA_DIR.'includes/class-hotels.php';
require_once STA_DIR.'includes/class-termpage.php';
require_once STA_DIR.'includes/class-listings-admin.php';
require_once STA_DIR.'includes/class-templates.php';
require_once STA_DIR.'includes/class-admin.php';

add_action('plugins_loaded', function () {
    load_plugin_textdomain('seeinside-travel', false, dirname(plugin_basename(STA_FILE)).'/languages');

    STA_Api::init();
    STA_Post_Types::init();
    STA_Fields::init();
    STA_Sync::init();
    STA_Webhook::init();
    STA_Frontend::init();
    STA_Slider::init();
    STA_Reviews::init();
    STA_Chat::init();
    STA_Listings::init();
    STA_Finder::init();
    STA_Offer_Finder::init();
    STA_Site::init();
    STA_Search_Box::init();
    STA_Quick_Search::init();
    STA_Hotels::init();
    STA_Term_Page::init();
    STA_Listings_Admin::init();
    STA_Templates::init();
    if (is_admin()) {
        STA_Admin::init();
    }
});

// after an update (new post types / taxonomies): refresh the permalinks once
add_action('init', function () {
    if (get_option('sta_rewrite_version') !== STA_VERSION) {
        flush_rewrite_rules(false);
        update_option('sta_rewrite_version', STA_VERSION, true);
    }
}, 99);

register_activation_hook(__FILE__, function () {
    STA_Post_Types::register();
    flush_rewrite_rules();
    STA_Sync::schedule();
});

register_deactivation_hook(__FILE__, function () {
    wp_clear_scheduled_hook('sta_cron_changes');
    wp_clear_scheduled_hook('sta_process_queue');
    flush_rewrite_rules();
});
