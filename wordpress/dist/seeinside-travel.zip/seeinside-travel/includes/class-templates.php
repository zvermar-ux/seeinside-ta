<?php

defined('ABSPATH') || exit;

/**
 * Detects the page builder and prepares templates for it:
 *  - Elementor Pro: Theme Builder "Single" and "Archive" templates per post type, made of our widgets
 *  - Elementor (free) / Gutenberg / Divi / Bricks / WPBakery / classic theme: automatic layout + shortcodes / blocks
 */
class STA_Templates
{
    public static function init(): void
    {
        add_action('elementor/widgets/register', [self::class, 'elementor_widgets']);
        add_action('elementor/elements/categories_registered', function ($manager) {
            $manager->add_category('seeinside-travel', ['title' => 'SeeInside Travel', 'icon' => 'fa fa-plane']);
        });
        add_action('init', [self::class, 'blocks']);
    }

    /** elementor_pro | elementor | divi | bricks | wpbakery | oxygen | beaver | block_theme | classic */
    public static function builder(): string
    {
        if (defined('ELEMENTOR_PRO_VERSION')) {
            return 'elementor_pro';
        }
        if (defined('ELEMENTOR_VERSION')) {
            return 'elementor';
        }
        if (defined('ET_BUILDER_VERSION')) {
            return 'divi';
        }
        if (defined('BRICKS_VERSION')) {
            return 'bricks';
        }
        if (defined('WPB_VC_VERSION')) {
            return 'wpbakery';
        }
        if (defined('CT_VERSION')) {
            return 'oxygen';
        }
        if (class_exists('FLBuilder')) {
            return 'beaver';
        }

        return function_exists('wp_is_block_theme') && wp_is_block_theme() ? 'block_theme' : 'classic';
    }

    public static function builder_label(): string
    {
        return [
            'elementor_pro' => 'Elementor Pro',
            'elementor' => 'Elementor',
            'divi' => 'Divi',
            'bricks' => 'Bricks',
            'wpbakery' => 'WPBakery',
            'oxygen' => 'Oxygen',
            'beaver' => 'Beaver Builder',
            'block_theme' => __('Block theme (Gutenberg)', 'seeinside-travel'),
            'classic' => __('Classic theme', 'seeinside-travel'),
        ][self::builder()];
    }

    /** Elementor Pro has a Theme Builder template for the current page in this location? */
    protected static function elementor_location_has(string $location): bool
    {
        if (! class_exists('\ElementorPro\Modules\ThemeBuilder\Module')) {
            return false;
        }
        try {
            $docs = \ElementorPro\Modules\ThemeBuilder\Module::instance()->get_conditions_manager()->get_documents_for_location($location);

            return ! empty($docs);
        } catch (Throwable $e) {
            return false;
        }
    }

    /** Should the plugin print the whole page into the content? */
    public static function use_auto_layout(string $postType, int $postId): bool
    {
        if (sta_setting('layout_mode', 'auto') === 'off') {
            return false;
        }
        if (get_post_meta($postId, '_elementor_edit_mode', true) === 'builder') {
            return false;
        }

        return ! self::elementor_location_has('single');
    }

    public static function use_auto_archive(): bool
    {
        return sta_setting('layout_mode', 'auto') !== 'off' && sta_setting('archive_mode', 'auto') !== 'theme' && ! self::elementor_location_has('archive');
    }

    /* ======================== Elementor ======================== */

    public static function elementor_widgets($manager): void
    {
        require_once STA_DIR.'includes/elementor/widgets.php';
        foreach (sta_elementor_widget_classes() as $class) {
            $manager->register(new $class());
        }
    }

    protected static function eid(): string
    {
        return substr(md5(wp_generate_uuid4()), 0, 7);
    }

    protected static function widget(string $type, array $settings = []): array
    {
        return ['id' => self::eid(), 'elType' => 'widget', 'widgetType' => $type, 'settings' => (object) $settings, 'elements' => []];
    }

    protected static function section(array $columns, array $settings = []): array
    {
        return [
            'id' => self::eid(), 'elType' => 'section', 'isInner' => false,
            'settings' => (object) ($settings + ['gap' => 'extended']),
            'elements' => array_map(fn ($c) => [
                'id' => self::eid(), 'elType' => 'column', 'isInner' => false,
                'settings' => (object) (['_column_size' => $c['size'], '_inline_size' => null] + ($c['settings'] ?? [])),
                'elements' => $c['widgets'],
            ], $columns),
        ];
    }

    protected static function single_layout(string $postType): array
    {
        $type = STA_Schema::api_type($postType);
        $main = ['gallery', 'facts', 'fields', 'description', 'amenities', 'info_cards', 'highlights', 'program', 'route_map', 'departures', 'rooms', 'terms', 'availability', 'tickets', 'requirements', 'included', 'extras', 'info', 'galleries', 'videos', 'map', 'booking', 'reviews'];
        $skip = [
            'tour' => ['rooms', 'availability', 'tickets', 'requirements', 'amenities'],
            'event' => ['highlights', 'program', 'departures', 'rooms', 'availability', 'requirements', 'extras', 'amenities'],
            'accommodation' => ['highlights', 'program', 'departures', 'tickets', 'requirements', 'extras', 'included'],
            'visa' => ['highlights', 'program', 'departures', 'rooms', 'availability', 'tickets', 'included', 'extras', 'amenities', 'map', 'videos'],
        ][$type] ?? [];
        $main = array_values(array_diff($main, $skip));

        return [
            self::section([['size' => 100, 'widgets' => [self::widget('theme-post-title', ['header_size' => 'h1'])]]]),
            self::section([
                ['size' => 66, 'widgets' => array_map(fn ($s) => self::widget('sta-section', ['section' => $s]), $main)],
                ['size' => 33, 'widgets' => [self::widget('sta-section', ['section' => 'price', 'sticky' => 'top', '_css_classes' => 'sta-sticky'])]],
            ]),
        ];
    }

    protected static function archive_layout(string $postType): array
    {
        $search = ['sta_tour' => 'tour', 'sta_hotel' => 'accommodation', 'sta_event' => 'event', 'sta_visa' => 'visa'][$postType];

        return [
            self::section([['size' => 100, 'widgets' => [
                self::widget('theme-archive-title', ['header_size' => 'h1']),
                self::widget('sta-search', ['types' => $search]),
                self::widget('sta-list', ['query' => 'current', 'columns' => '3', 'pagination' => 'yes']),
            ]]]),
        ];
    }

    /** Page of a destination / place / group / tour type / accommodation type */
    protected static function term_layout(string $tax): array
    {
        $types = [
            'sta_tour_type' => 'tour', 'sta_hotel_type' => 'accommodation', 'sta_event_category' => 'event',
        ][$tax] ?? 'tour,accommodation,event';

        return [
            self::section([['size' => 100, 'widgets' => [self::widget('sta-term-header', ['preview_tax' => $tax, 'height' => 340])]]], ['layout' => 'full_width', 'stretch_section' => 'section-stretched']),
            self::section([['size' => 100, 'widgets' => [self::widget('sta-term-offers', ['preview_tax' => $tax, 'types' => explode(',', $types), 'children' => 'yes', 'columns' => 3])]]]),
        ];
    }

    /** Which templates the plugin makes: key => [title, document type, layout, conditions] */
    protected static function template_plan(): array
    {
        $plan = [];
        foreach (STA_Schema::post_types() as $postType => $pt) {
            $plan[$postType.':single-post'] = [$pt['plural'].' – SeeInside', 'single-post', fn () => self::single_layout($postType), ['include/singular/'.$postType]];
            $plan[$postType.':archive'] = [__('List', 'seeinside-travel').': '.$pt['plural'].' – SeeInside', 'archive', fn () => self::archive_layout($postType), ['include/archive/'.$postType.'_archive']];
        }
        // one page design per taxonomy: destinations, places, groups, tour types, accommodation types, event categories
        foreach (['sta_destination', 'sta_place', 'sta_group', 'sta_tour_type', 'sta_hotel_type', 'sta_event_category'] as $tax) {
            $t = STA_Schema::taxonomies()[$tax] ?? null;
            if ($t) {
                $plan['tax:'.$tax] = [__('Page', 'seeinside-travel').': '.$t['plural'].' – SeeInside', 'archive', fn () => self::term_layout($tax), ['include/archive/'.$tax]];
            }
        }
        // own single design per accommodation type (hotel, apartment, villa…) – starts as the hotel design
        $hotelTypes = get_terms(['taxonomy' => 'sta_hotel_type', 'hide_empty' => false]);
        foreach (is_wp_error($hotelTypes) ? [] : $hotelTypes as $ht) {
            $plan['hoteltype:'.$ht->slug] = [__('Apartment', 'seeinside-travel').': '.$ht->name.' – SeeInside', 'single-post', fn () => self::single_layout('sta_hotel'), ['include/singular/in_sta_hotel_type/'.$ht->term_id]];
        }

        return $plan;
    }

    /**
     * Elementor Pro: create (or re-create) the Theme Builder templates. Existing templates made by the plugin
     * are left alone unless $replace is true, so the user's own design changes are kept.
     */
    public static function create_elementor_templates(bool $replace = false): array
    {
        if (! defined('ELEMENTOR_VERSION')) {
            return ['error' => __('Elementor is not active.', 'seeinside-travel')];
        }
        $made = [];
        $known = get_option('sta_elementor_templates', []);

        foreach (self::template_plan() as $key => [$title, $docType, $layoutFn, $conditions]) {
            $existing = (int) ($known[$key] ?? 0);
            if ($existing && get_post_status($existing) && ! $replace) {
                continue;
            }
            $id = $existing && get_post_status($existing) ? $existing : wp_insert_post([
                'post_type' => 'elementor_library',
                'post_status' => 'publish',
                'post_title' => $title,
            ]);
            if (is_wp_error($id) || ! $id) {
                continue;
            }
            wp_set_object_terms($id, $docType, 'elementor_library_type');
            update_post_meta($id, '_elementor_template_type', $docType);
            update_post_meta($id, '_elementor_edit_mode', 'builder');
            update_post_meta($id, '_elementor_version', ELEMENTOR_VERSION);
            if (defined('ELEMENTOR_PRO_VERSION')) {
                update_post_meta($id, '_elementor_pro_version', ELEMENTOR_PRO_VERSION);
            }
            update_post_meta($id, '_elementor_data', wp_slash(wp_json_encode($layoutFn())));
            update_post_meta($id, '_elementor_page_settings', []);
            update_post_meta($id, '_elementor_conditions', $conditions);
            delete_post_meta($id, '_elementor_css');
            $known[$key] = $id;
            $made[] = $title;
        }
        // older versions showed destination / group pages with the tour list – they now have their own pages
        if (! empty($known['sta_tour:archive']) && get_post_status($known['sta_tour:archive'])) {
            update_post_meta($known['sta_tour:archive'], '_elementor_conditions', ['include/archive/sta_tour_archive']);
        }
        update_option('sta_elementor_templates', $known, false);

        if (class_exists('\ElementorPro\Modules\ThemeBuilder\Module')) {
            try {
                \ElementorPro\Modules\ThemeBuilder\Module::instance()->get_conditions_manager()->get_cache()->regenerate();
            } catch (Throwable $e) {
                sta_log('elementor conditions: '.$e->getMessage(), 'error');
            }
        }
        if (class_exists('\Elementor\Plugin')) {
            \Elementor\Plugin::$instance->files_manager->clear_cache();
        }
        sta_log('elementor templates: '.implode(', ', $made));

        return ['made' => $made];
    }

    /* ======================== one design for every list ======================== */

    /** Settings that belong to one page (what it shows, its photo, titles) – never copied between pages */
    protected const OWN_SETTINGS = ['preview_tax', 'page_type', 'page_title', 'page_label', 'bg_image', 'bg_mode', 'types', 'children',
        'title_accommodation', 'title_tour', 'title_event', 'title_children', '__globals__'];

    /** The four listing pages and what they show */
    public const LIST_PAGES = ['aranzmani' => 'tour', 'hoteli' => 'hotels', 'apartmani' => 'accommodation', 'nastani' => 'event'];

    /** First widget of a type in Elementor data (by reference) */
    protected static function &find_widget(array &$els, string $type)
    {
        $none = null;
        foreach ($els as &$el) {
            if (($el['elType'] ?? '') === 'widget' && ($el['widgetType'] ?? '') === $type) {
                return $el;
            }
            if (! empty($el['elements'])) {
                $hit = &self::find_widget($el['elements'], $type);
                if ($hit !== null) {
                    return $hit;
                }
                unset($hit);
            }
        }

        return $none;
    }

    protected static function data(int $id): array
    {
        $raw = get_post_meta($id, '_elementor_data', true);
        $data = is_array($raw) ? $raw : json_decode((string) $raw, true);

        return is_array($data) ? $data : [];
    }

    protected static function save_data(int $id, array $data): void
    {
        update_post_meta($id, '_elementor_data', wp_slash(wp_json_encode($data)));
        delete_post_meta($id, '_elementor_css');
    }

    /** Design settings of a widget (everything but what belongs to one page) */
    protected static function design(?array $widget): array
    {
        return $widget ? array_diff_key((array) ($widget['settings'] ?? []), array_flip(self::OWN_SETTINGS)) : [];
    }

    /** Taxonomies whose pages share one design */
    public const LIST_TAXES = ['sta_destination', 'sta_place', 'sta_group', 'sta_tour_type', 'sta_hotel_type', 'sta_event_category'];

    /** Page id of a listing page (saved by "Create pages", or found by its address) */
    protected static function list_page_id(string $slug): int
    {
        $pages = get_option('sta_pages', []);
        $id = (int) ($pages[$slug] ?? 0);
        if ($id && in_array(get_post_status($id), ['publish', 'draft', 'private'], true)) {
            return $id;
        }
        if ($slug === 'hoteli' && STA_Hotels::enabled()) {
            $id = url_to_postid(STA_Hotels::page_url());
            if ($id) {
                return $id;
            }
        }
        $p = get_page_by_path($slug);

        return $p && $p->post_status !== 'trash' ? (int) $p->ID : 0;
    }

    /** Elementor data with every element id renewed (a copy must not share ids with the original) */
    protected static function renew_ids(array $els): array
    {
        foreach ($els as &$el) {
            $el['id'] = self::eid();
            if (! empty($el['elements'])) {
                $el['elements'] = self::renew_ids($el['elements']);
            }
        }

        return $els;
    }

    /**
     * One design for every list. The template of the accommodation-type pages (as designed in Elementor) becomes
     * THE template of the pages of destinations, places, groups, tour types, accommodation types and event
     * categories (later changes there show everywhere at once), and the pages Organized tours, Hotels, Apartments
     * and Events get an exact copy of it (click again after changing the design). Each page keeps its own photo.
     */
    public static function unify_design(string $from = 'tax:sta_hotel_type'): array
    {
        if (! defined('ELEMENTOR_VERSION')) {
            return ['error' => __('Elementor is not active.', 'seeinside-travel')];
        }
        self::create_elementor_templates(false);
        $known = get_option('sta_elementor_templates', []);
        $ref = (int) ($known[$from] ?? 0);
        if (! $ref || ! get_post_status($ref)) {
            return ['error' => __('The template "Page: Accommodation types – SeeInside" was not found. Click "Create Elementor templates" first.', 'seeinside-travel')];
        }
        $data = self::data($ref);
        // the list shows whatever fits the page (tours, apartments, events), the header the term of the page
        $o = &self::find_widget($data, 'sta-term-offers');
        if ($o !== null) {
            $o['settings'] = array_merge((array) $o['settings'], ['types' => ['tour', 'accommodation', 'event']]);
        }
        unset($o);
        self::save_data($ref, $data);
        $made = [];
        $notes = [];

        // 1. one template for all the term pages; the other term templates are kept, without conditions (undo)
        $backup = get_option('sta_unify_backup', []);
        $conditions = array_map(fn ($tax) => 'include/archive/'.$tax, self::LIST_TAXES);
        update_post_meta($ref, '_elementor_conditions', $conditions);
        wp_update_post(['ID' => $ref, 'post_title' => __('Page: lists (destinations, places, groups, types) – SeeInside', 'seeinside-travel')]);
        foreach ($known as $key => $id) {
            if (! str_starts_with($key, 'tax:') || $key === $from || ! get_post_status($id)) {
                continue;
            }
            $backup['conditions'][$id] ??= get_post_meta($id, '_elementor_conditions', true);
            update_post_meta($id, '_elementor_conditions', []);
        }
        update_option('sta_unify_backup', $backup, false);
        $made[] = __('pages of destinations, places, groups and types', 'seeinside-travel');

        // 2. the archives of tours, events and accommodation (/aranzmani/, /nastani/… when the address is the archive)
        foreach (['sta_tour:archive' => 'tour', 'sta_event:archive' => 'event', 'sta_hotel:archive' => 'accommodation'] as $key => $type) {
            $id = (int) ($known[$key] ?? 0);
            if (! $id || ! get_post_status($id)) {
                continue;
            }
            $backup['archives'][$id] ??= get_post_meta($id, '_elementor_data', true);
            $copy = self::renew_ids($data);
            $h = &self::find_widget($copy, 'sta-term-header');
            if ($h !== null) {
                $h['settings'] = array_merge((array) $h['settings'], ['page_type' => $type]);
            }
            unset($h);
            $l = &self::find_widget($copy, 'sta-term-offers');
            if ($l !== null) {
                $l['settings'] = array_merge((array) $l['settings'], ['page_type' => $type, 'show_titles' => '']);
            }
            unset($l);
            self::save_data($id, $copy);
            $made[] = get_the_title($id);
        }
        update_option('sta_unify_backup', $backup, false);

        // 3. the listing pages: an exact copy of the same design, showing their list
        foreach (self::LIST_PAGES as $slug => $type) {
            if ($type === 'hotels' && ! STA_Hotels::enabled()) {
                continue;
            }
            $pid = self::list_page_id($slug);
            if (! $pid) {
                $notes[] = sprintf(__('Page /%s/ not found – click "Create pages" first.', 'seeinside-travel'), $slug);

                continue;
            }
            $old = self::data($pid);
            $oldHead = self::find_widget($old, 'sta-term-header');
            if (! get_post_meta($pid, '_sta_backup_content', true)) {
                update_post_meta($pid, '_sta_backup_content', ['content' => get_post_field('post_content', $pid), 'elementor' => get_post_meta($pid, '_elementor_data', true),
                    'template' => get_post_meta($pid, '_wp_page_template', true), 'mode' => get_post_meta($pid, '_elementor_edit_mode', true)]);
            }
            $copy = self::renew_ids($data);
            $h = &self::find_widget($copy, 'sta-term-header');
            if ($h !== null) {
                // the photo chosen on this page stays
                $own = $oldHead ? array_intersect_key((array) $oldHead['settings'], array_flip(['bg_image', 'bg_mode', 'page_title', 'page_label'])) : [];
                $h['settings'] = array_merge((array) $h['settings'], ['page_type' => $type], $own);
                if (empty($own['bg_image']['url'])) {
                    unset($h['settings']['bg_image']);
                }
            }
            unset($h);
            $l = &self::find_widget($copy, 'sta-term-offers');
            if ($l !== null) {
                $l['settings'] = array_merge((array) $l['settings'], ['page_type' => $type, 'show_titles' => '']);
            }
            unset($l);
            wp_update_post(['ID' => $pid, 'post_content' => '[sta_term_header page_type="'.$type.'"]'."\n".'[sta_term_offers page_type="'.$type.'" titles=""]']);
            update_post_meta($pid, '_elementor_edit_mode', 'builder');
            update_post_meta($pid, '_elementor_template_type', 'wp-page');
            update_post_meta($pid, '_elementor_version', ELEMENTOR_VERSION);
            update_post_meta($pid, '_wp_page_template', 'elementor_header_footer');   // full width, no theme title – like the archive pages
            self::save_data($pid, $copy);
            $made[] = get_the_title($pid);
        }
        if (class_exists('\ElementorPro\Modules\ThemeBuilder\Module')) {
            try {
                \ElementorPro\Modules\ThemeBuilder\Module::instance()->get_conditions_manager()->get_cache()->regenerate();
            } catch (Throwable $e) {
                sta_log('elementor conditions: '.$e->getMessage(), 'error');
            }
        }
        if (class_exists('\Elementor\Plugin')) {
            \Elementor\Plugin::$instance->files_manager->clear_cache();
        }
        sta_log('unified design: '.implode(', ', $made).' '.implode(' ', $notes));

        return ['made' => $made, 'notes' => $notes];
    }

    /** Back to how a listing page was before the unified design */
    public static function restore_list_pages(): int
    {
        $n = 0;
        foreach (array_keys(self::LIST_PAGES) as $slug) {
            $pid = self::list_page_id($slug);
            $b = $pid ? get_post_meta($pid, '_sta_backup_content', true) : null;
            if (! is_array($b)) {
                continue;
            }
            wp_update_post(['ID' => $pid, 'post_content' => $b['content'] ?? '']);
            if (! empty($b['elementor'])) {
                update_post_meta($pid, '_elementor_data', wp_slash(is_string($b['elementor']) ? $b['elementor'] : wp_json_encode($b['elementor'])));
            } else {
                delete_post_meta($pid, '_elementor_data');
                delete_post_meta($pid, '_elementor_edit_mode');
            }
            update_post_meta($pid, '_wp_page_template', $b['template'] ?: 'default');
            if (! empty($b['mode'])) {
                update_post_meta($pid, '_elementor_edit_mode', $b['mode']);
            }
            delete_post_meta($pid, '_sta_backup_content');
            $n++;
        }
        // the term templates get their own conditions back
        $backup = get_option('sta_unify_backup', []);
        $known = get_option('sta_elementor_templates', []);
        foreach ((array) ($backup['archives'] ?? []) as $id => $old) {
            if ($old) {
                update_post_meta((int) $id, '_elementor_data', wp_slash(is_string($old) ? $old : wp_json_encode($old)));
                delete_post_meta((int) $id, '_elementor_css');
            }
        }
        if (! empty($backup['conditions'])) {
            foreach ($backup['conditions'] as $id => $cond) {
                update_post_meta((int) $id, '_elementor_conditions', $cond ?: []);
            }
            if (! empty($known['tax:sta_hotel_type'])) {
                update_post_meta((int) $known['tax:sta_hotel_type'], '_elementor_conditions', ['include/archive/sta_hotel_type']);
            }
            if (class_exists('\ElementorPro\Modules\ThemeBuilder\Module')) {
                try {
                    \ElementorPro\Modules\ThemeBuilder\Module::instance()->get_conditions_manager()->get_cache()->regenerate();
                } catch (Throwable $e) {
                }
            }
        }

        delete_option('sta_unify_backup');

        return $n;
    }

    /* ======================== pages ======================== */

    /** Ready pages with listings (shortcodes work in every builder / editor) */
    public static function create_pages(): array
    {
        $pages = [
            'aranzmani' => [__('Organized tours', 'seeinside-travel'), "[sta_search types=\"tour\"]\n[sta_list type=\"tour\" limit=\"12\" columns=\"3\" search=\"1\" pagination=\"1\" orderby=\"departure\"]"],
            // hotels only from the booking system (live prices); own accommodation of every type → "Apartments"
            'hoteli' => [__('Hotels', 'seeinside-travel'), '[sta_hotels]'],
            'apartmani' => [__('Apartments', 'seeinside-travel'), '[sta_hotel_finder]'],
            'nastani' => [__('Events', 'seeinside-travel'), '[sta_list type="event" limit="12" columns="3" orderby="departure" pagination="1"]'],
            'vizi' => [__('Visas', 'seeinside-travel'), '[sta_list type="visa" limit="24" columns="4" orderby="title"]'],
            'last-minute' => ['Last minute', '[sta_last_minute limit="24" columns="3"]'],
            'carteri' => [__('Charter seats', 'seeinside-travel'), '[sta_charters]'],
            'avio-karti' => [__('Flights', 'seeinside-travel'), '[sta_flight_search]'],
            'proveri-rezervacija' => [__('Check your booking', 'seeinside-travel'), '[sta_booking_status]'],
            'kontakt' => [__('Contact', 'seeinside-travel'), '[sta_contacts]'],
        ];
        // the hotels page made by an older version (search + plain list) → filters on the left
        $old = "[sta_search types=\"accommodation\"]\n[sta_list type=\"hotel\" limit=\"12\" columns=\"3\" search=\"1\" pagination=\"1\"]";
        $made = [];
        $notes = [];
        $known = get_option('sta_pages', []);
        $live = fn ($id) => $id && in_array(get_post_status($id), ['publish', 'draft', 'private', 'future', 'pending'], true);
        // the hotels setting may be older than the app: ask the app once more
        if (! STA_Hotels::enabled() && STA_Api::configured()) {
            STA_Sync::sync_meta();
        }
        foreach ($pages as $slug => [$title, $content]) {
            if ($slug === 'hoteli') {
                self::hotels_page($known, $title, $content, $old, $made, $notes);
                continue;
            }
            if (! empty($known[$slug]) && $live($known[$slug])) {
                $now = trim(str_replace("\r", '', (string) get_post_field('post_content', $known[$slug])));
                // apartments: every type of own accommodation (apartments, studios, own hotels…)
                if ($slug === 'apartmani' && $now === '[sta_hotel_finder exclude_type="hotel"]') {
                    wp_update_post(['ID' => $known[$slug], 'post_content' => $content, 'post_title' => $title]);
                    $made[] = $title;
                }
                continue;
            }
            if ($slug === 'apartmani' && ! self::own_apartments()) {
                continue;   // no own accommodation yet
            }
            $existing = get_page_by_path($slug);
            if ($existing && $live($existing->ID)) {
                $known[$slug] = $existing->ID;
                continue;
            }
            $id = wp_insert_post(['post_type' => 'page', 'post_status' => 'publish', 'post_title' => $title, 'post_name' => $slug, 'post_content' => $content]);
            if ($id && ! is_wp_error($id)) {
                $known[$slug] = $id;
                $made[] = $title;
            }
        }
        update_option('sta_pages', $known, false);

        return ['made' => $made, 'notes' => $notes];
    }

    /**
     * Hotels page = the hotels from the booking system ([sta_hotels]). An old hotels page of the plugin is converted;
     * a page with other content (own design) is left alone and a new "Hotels" page is made.
     */
    protected static function hotels_page(array &$known, string $title, string $content, string $old, array &$made, array &$notes): void
    {
        if (! STA_Hotels::enabled()) {
            $notes[] = __('Hotels page: hotels from a booking system are not on yet. In the app, Booking systems (API) → Hotelbeds must be active with destinations switched on; then click "Sync all" and create the pages again.', 'seeinside-travel');

            return;
        }
        $live = fn ($id) => $id && in_array(get_post_status($id), ['publish', 'draft', 'private', 'future', 'pending'], true);
        // already there
        if (! empty($known['hoteli']) && $live($known['hoteli']) && has_shortcode((string) get_post_field('post_content', $known['hoteli']), 'sta_hotels')) {
            if (get_post_status($known['hoteli']) !== 'publish') {
                wp_update_post(['ID' => $known['hoteli'], 'post_status' => 'publish']);
                $made[] = $title;
            }

            return;
        }
        foreach (get_posts(['post_type' => 'page', 'post_status' => 'publish', 'numberposts' => 20, 's' => '[sta_hotels']) as $p) {
            if (has_shortcode($p->post_content, 'sta_hotels')) {
                $known['hoteli'] = $p->ID;

                return;
            }
        }
        // an old hotels page of the plugin (own accommodation) → the hotel search
        if (! empty($known['hoteli']) && $live($known['hoteli'])) {
            $now = trim(str_replace("\r", '', (string) get_post_field('post_content', $known['hoteli'])));
            if ($now === '' || $now === $old || preg_match('/^\[sta_hotel_finder[^\]]*\]$/', $now)) {
                wp_update_post(['ID' => $known['hoteli'], 'post_content' => $content, 'post_title' => $title, 'post_status' => 'publish']);
                delete_post_meta($known['hoteli'], '_elementor_edit_mode');   // show the shortcode, not an old Elementor layout
                $made[] = $title;

                return;
            }
        }
        // a new page: /hoteli/ when free, otherwise /hoteli-online/
        $slug = 'hoteli';
        $taken = get_page_by_path($slug);
        if ($taken && $live($taken->ID)) {
            $slug = 'hoteli-online';
        }
        $id = wp_insert_post(['post_type' => 'page', 'post_status' => 'publish', 'post_title' => $title, 'post_name' => $slug, 'post_content' => $content]);
        if ($id && ! is_wp_error($id)) {
            $known['hoteli'] = $id;
            $made[] = $title.' (/'.get_post_field('post_name', $id).'/)';
        }
    }

    /** Own accommodation entered in the app (apartments, studios, villas, own hotels…) exists */
    protected static function own_apartments(): bool
    {
        return (bool) wp_count_posts('sta_hotel')->publish;
    }

    /* ======================== Gutenberg blocks ======================== */

    public static function blocks(): void
    {
        if (! function_exists('register_block_type')) {
            return;
        }
        wp_register_script('sta-blocks', STA_URL.'assets/js/blocks.js', ['wp-blocks', 'wp-element', 'wp-components', 'wp-block-editor', 'wp-server-side-render', 'wp-i18n'], STA_VERSION, true);
        wp_localize_script('sta-blocks', 'STA_BLOCKS', [
            'sections' => array_map(fn ($label) => __($label, 'seeinside-travel'), STA_Render::SECTIONS),
        ]);

        register_block_type('seeinside-travel/section', [
            'editor_script' => 'sta-blocks',
            'attributes' => ['section' => ['type' => 'string', 'default' => 'layout'], 'postId' => ['type' => 'number', 'default' => 0]],
            'render_callback' => fn ($a) => STA_Render::section($a['section'] ?? 'layout', ! empty($a['postId']) ? (int) $a['postId'] : null),
        ]);
        register_block_type('seeinside-travel/list', [
            'editor_script' => 'sta-blocks',
            'attributes' => [
                'type' => ['type' => 'string', 'default' => 'tour'], 'limit' => ['type' => 'number', 'default' => 6],
                'columns' => ['type' => 'number', 'default' => 3], 'lastMinute' => ['type' => 'boolean', 'default' => false],
                'destination' => ['type' => 'string', 'default' => ''], 'orderby' => ['type' => 'string', 'default' => 'date'],
            ],
            'render_callback' => fn ($a) => STA_Frontend::sc_list([
                'type' => $a['type'], 'limit' => $a['limit'], 'columns' => $a['columns'], 'last_minute' => $a['lastMinute'] ? '1' : '',
                'destination' => $a['destination'], 'orderby' => $a['orderby'],
            ]),
        ]);
        foreach (['slider' => 'sc_slider', 'search' => 'sc_search', 'flights' => 'sc_flights', 'charters' => 'sc_charters', 'status' => 'sc_status'] as $name => $cb) {
            register_block_type('seeinside-travel/'.$name, ['editor_script' => 'sta-blocks', 'render_callback' => fn () => STA_Frontend::$cb([])]);
        }
    }
}
